<?php
return [
    'start' => "<b>Olá! Eu sou um editor de música 🎧</b>

<blockquote>Eu vou te ajudar a editar músicas e trabalhar com arquivos de mídia.</blockquote>

<b>ℹ️ Aqui está o que eu posso fazer:</b>
🎵 Alterar o nome ou a capa da faixa — do jeito que você quiser.  
✂️ Cortar áudio — selecione o trecho desejado ou adicione uma transição suave.  
🌌 Adicionar efeito 8D — o som vai te cercar de todos os lados!  
📥 Baixar música do YouTube — basta enviar o link ou clicar em «🔍 Buscar música».  
📲 Baixar vídeos do TikTok, Pinterest e Instagram com áudio — tudo o que você quiser na palma da sua mão!  

<b>⁉️ Como começar?</b>  
<blockquote>Envie para mim:  
🎶 Uma música,  
🎥 Um vídeo,  
ou um link para uma faixa do YouTube!</blockquote>

<b>Eu funciono em grupos e realizo pedidos de forma rápida e eficiente 🚀</b>",

    'file_too_large' => "O arquivo é muito grande 🚫",
    'processing' => "Por favor, aguarde... ⏳",
    'error_processing_audio' => "Erro ao processar o áudio ❌",
    'download_failed' => "Não foi possível baixar o arquivo de áudio ❌",
    'unsupported_format' => "Este formato de áudio não é suportado 🚫",
    'unknown' => "Desconhecido",
    'music_name' => "🎶 Nome da música",
    'artist_name' => "🎤 Nome do artista",
    'file_size' => "📂 Tamanho do arquivo",
    'duration' => "⏱️ Duração",
    'no_music' => "Nenhuma música! Primeiro, envie um arquivo de áudio 🎵",
    'send_new_tags' => "Envie novas tags no formato:\n🎶 Nome da música\n🎤 Nome do artista",
    'send_new_photo' => "Envie uma nova foto 🖼️",
    'enter_time_interval' => "Informe o intervalo de tempo em segundos para cortar o áudio. Exemplo: 0 - 80 ⏱️",
    'incorrect_interval' => "Digite um intervalo de tempo válido no formato: início - fim. Exemplo: 0 - 80 ❗",
    'start_less_than_end' => "O tempo inicial deve ser menor que o tempo final. Tente novamente ❗",
    'end_exceeds_duration' => "O tempo final excede a duração do áudio. Tente novamente ❗",
    'error_trimming_audio' => "Erro ao cortar o áudio ❌",
    'no_audio_to_trim' => "Nenhuma música para cortar 🚫",
    'no_audio_to_convert' => "Nenhuma música para converter 🚫",
    'audio_too_long' => "O áudio tem mais de 4 minutos. Corte-o primeiro ⏳",
    'error_converting_to_voice' => "Erro ao converter para voz ❌",
    'error_saving_audio' => "Erro ao salvar o áudio ❌",
    'audio_saved' => "Áudio salvo e enviado com sucesso! 🎉",
    'no_audio_to_save' => "Nenhuma música para salvar 🚫",
    'error_updating_photo' => "Erro ao atualizar a foto ❌",
    'no_message_to_update' => "Nenhuma mensagem encontrada para atualização ❌",
    'error_processing_photo' => "Erro ao processar a foto ❌",
    'error_saving_photo' => "Não foi possível salvar a foto ❌",
    'no_audio_duration' => "Não foi possível obter a duração do áudio ❌",
    'no_audio_to_join' => "Não foi possível verificar a inscrição nos canais ❌",
    'join_channels_prompt' => "❗️ Para obter música, primeiro inscreva-se nos canais abaixo e depois clique em «✅️ Já me inscrevi».",
    'setting_photo' => "🖼️ Alterar foto",
    'setting_music_name' => "🎶 Alterar nome da música",
    'setting_performer' => "🎤 Alterar nome do artista",
    'close' => "❌ Fechar",
    'add_photo' => "🖼️ Adicionar foto",
    'add_music_name' => "🎶 Adicionar nome da música",
    'add_performer' => "🎤 Adicionar nome do artista",
    'set_music_empty' => "📎 Definir como vazio",
    'leave_music_as_is' => "✅ Manter como está",
    'enter_new_music_name' => "✏️ Digite um novo nome",
    'cancel' => "🚫 Cancelar",
    'no_data_available' => "Nenhum dado disponível. Configure os dados e adicione uma foto.",
    'auto_settings_caption' => "🎛 Configurações de salvamento automático:\n🎵 Nome da música: {music_name}\n🎤 Nome do artista: {performer_name}",
    'settings_with_no_data' => "🎛 Configurações de salvamento automático:\nNenhum dado disponível.",
    'settings_saved' => "Configurações atualizadas com sucesso.",
    'no_autosave_set' => "O salvamento automático não está configurado. Use o comando /setting para configurar.",
    'configure_autosave' => "Configurar salvamento automático ⚙️",
    'audio_file_not_found' => "Arquivo de áudio não encontrado. Envie uma música.",
    'image_not_found' => "Imagem não encontrada.",
    'search_prompt' => "<b>Para encontrar uma música, clique em «🔍 Buscar música». Digite o nome da canção e escolha uma das opções sugeridas.</b>",
    'choose_lang' => "Escolha um idioma 🌐👇🏻",
    'btn_lang' => "🌐 Alterar idioma",
    'btn_back' => "« Voltar",
    'btn_main' => "🏠 Menu principal",
    'add_me_group' => "👥️ Adicionar ao grupo",
    'ad1_text' => "Compartilhe comigo seus amigos!",
    'ad1_button' => "Compartilhar",
    'ad1_share' => "Bot de edição e busca de música, experimente 🎀\n@ToolMp3_bot",
    'ad2_text' => "Adicione-me ao grupo, eu sei trabalhar em grupos!",
    'ad2_button' => "Adicionar ao grupo",
    'ad2_url' => "https://t.me/ToolMp3_bot?startgroup=on&admin=delete_messages"
];